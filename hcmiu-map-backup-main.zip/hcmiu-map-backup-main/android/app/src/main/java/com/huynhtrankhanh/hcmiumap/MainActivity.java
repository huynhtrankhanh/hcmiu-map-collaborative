package com.huynhtrankhanh.hcmiumap;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
